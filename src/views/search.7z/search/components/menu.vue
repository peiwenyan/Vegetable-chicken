<template>
  <div>
  <h4>政策检索平台</h4>
  <ul>
    <li>
      <h6>政策级别</h6>
      <a href='' target='_blank'>国家级</a>
      <a href='' target='_blank'>省级</a>
    </li>
    <li>
      <h6>行业分类</h6>
      <a href='' target='_blank'>教育</a>
      <a href='' target='_blank'>环保</a>
      <a href='' target='_blank'>农业</a>
      <a href='' target='_blank'>医疗</a>
      <a href='' target='_blank'>互联网</a>
      <a href='' target='_blank'>科学技术</a>
      <a href='' target='_blank'>建筑</a>
      <a href='' target='_blank'>法律</a>
      <a href='' target='_blank'>交通</a>
      <a href='' target='_blank'>餐饮</a>
      <a href='' target='_blank'>工业</a>
      <a href='' target='_blank'>旅游</a>
    </li>
  </ul>
  </div>
</template>

<script>
export default {
  name: 'menu'
}
</script>

<style scoped>
li>a {
  margin-right: 12px;
  font-size: 12px;
  color: #778193;
  line-height: 22px;
}

a {
  white-space: nowrap;
}
</style>
